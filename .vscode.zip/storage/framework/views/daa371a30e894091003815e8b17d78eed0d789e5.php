

<?php $__env->startSection('page'); ?>
    <?php $currentPage = 'users' ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <h2 class="title-1 m-b-25" style="     font-size: 24px;
font-weight: bold;
text-align: center;
padding: 10px;
color: white;
background-color: #332a2a; /* Color de fondo */
border-radius: 8px; /* Bordes redondeados */
box-shadow: 0 4px 8px rgba(26, 24, 24, 0.2); /* Sombra */
transition: transform 0.3s;">Lista de Usuarios</h2>
        <div class="table-responsive table--no-card m-b-40">
            <table class="table table-borderless table-striped table-earning">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>First name</th>
                        <th>Last name</th>
                        <th class="text-right">Email</th>
                        <th class="text-right">Phone</th>
                        <th class="text-right">Date</th>
                        <th></th> 
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->first_name); ?></td>
                        <td><?php echo e($user->last_name); ?></td>
                        <td class="text-right"><?php echo e($user->email); ?></td>
                        <td class="text-right"><?php echo e($user->phone_number); ?></td>
                        <td class="text-right"><?php echo e($user->created_at); ?></td>
                        <td>
                            <div class="table-data-feature">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.show')): ?>
                                <a href="<?php echo e(route('users.show', $user->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="View">
                                    <i class="fa fa-eye"></i>
                                </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.edit')): ?>
                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
                                    <i class="zmdi zmdi-edit"></i>
                                </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.destroy')): ?>
                                <form method="POST" action="<?php echo e(route('users.destroy', $user->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete">
                                        <i class="zmdi zmdi-delete"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rbacLaravel\resources\views/layouts/users/list.blade.php ENDPATH**/ ?>